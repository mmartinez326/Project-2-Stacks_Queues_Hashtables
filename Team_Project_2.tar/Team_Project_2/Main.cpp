// Project 02 - Stack , Queue , and Hash Table
// by:  Manuel Martinez , John Santoro , and Jim Bui

#include "Menu_Program.h"

int main () 
{
	Menu_Program() ;
}
